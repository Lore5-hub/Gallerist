<?php

class Utente {
    protected int $id;
    protected string $nome;
    protected string $cognome;
    protected string $dataNascita;
    protected string $indirizzo;
    protected string $nickname;
    protected string $email;
    protected string $password;
    protected string $ruolo; // 'utente' | 'artista' | 'admin'

    public function __construct(
        int $id,
        string $nome,
        string $cognome,
        string $dataNascita,
        string $indirizzo,
        string $nickname,
        string $email,
        string $password,
        string $ruolo = 'utente'
    ) {
        $this->id           = $id;
        $this->nome         = $nome;
        $this->cognome      = $cognome;
        $this->dataNascita  = $dataNascita;
        $this->indirizzo    = $indirizzo;
        $this->nickname     = $nickname;
        $this->email        = $email;
        $this->password     = $password;
        $this->ruolo        = $ruolo;
    }

    // --- Getter ---
    public function getId(): int            { return $this->id; }
    public function getNome(): string       { return $this->nome; }
    public function getCognome(): string    { return $this->cognome; }
    public function getDataNascita(): string{ return $this->dataNascita; }
    public function getIndirizzo(): string  { return $this->indirizzo; }
    public function getNickname(): string   { return $this->nickname; }
    public function getEmail(): string      { return $this->email; }
    public function getPassword(): string   { return $this->password; }
    public function getRuolo(): string      { return $this->ruolo; }
}
