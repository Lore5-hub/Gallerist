<?php

require_once __DIR__ . '/../Entity/Utente.php';
require_once __DIR__ . '/../Entity/Artista.php';
require_once __DIR__ . '/../Foundation/PersistentManager.php';
require_once __DIR__ . '/../Foundation/Session.php';

/**
 * CRegistrazione — Controller per UC1: Registrazione Account
 *
 * Operazioni di sistema gestite:
 *   - avviaRegistrazione()       → URL: ?controller=registrazione&task=avvia
 *   - registraUtente(...)        → URL: ?controller=registrazione&task=registraUtente  [POST]
 *   - registraArtista(...)       → URL: ?controller=registrazione&task=registraArtista [POST]
 */
class CRegistrazione {

    private PersistentManager $pm;

    public function __construct() {
        $this->pm = new PersistentManager();
    }

    // ---------------------------------------------------------------
    // Operazione 1: avvia — mostra il form di registrazione
    // ---------------------------------------------------------------
    public function avviaRegistrazione(): void {
        echo "[CRegistrazione] avviaRegistrazione() — mostro il form di registrazione\n";
        // In produzione: carica la View con il form
        // $view = new VRegistrazione();
        // $view->mostraForm();
    }

    // ---------------------------------------------------------------
    // Operazione 2: registra un utente standard
    // ---------------------------------------------------------------
    public function registraUtente(
        string $nome,
        string $cognome,
        string $dataNascita,
        string $indirizzo,
        string $nickname,
        string $email,
        string $password
    ): ?Utente {

        // Validazione base
        if ($this->pm->emailEsiste($email)) {
            echo "[CRegistrazione] ERRORE: email '$email' già registrata.\n";
            return null;
        }

        // Creazione oggetto di dominio
        $utente = new Utente(0, $nome, $cognome, $dataNascita, $indirizzo, $nickname, $email, password_hash($password, PASSWORD_DEFAULT));

        // Persistenza
        $utente = $this->pm->store($utente);

        // Login automatico in sessione
        Session::set('utente_id',   $utente->getId());
        Session::set('utente_ruolo', $utente->getRuolo());
        Session::set('nickname',     $utente->getNickname());

        echo "[CRegistrazione] Utente '{$utente->getNickname()}' registrato con successo!\n";
        echo "[CRegistrazione] → redirect a homepage + messaggio di successo\n";
        // In produzione: header('Location: index.php');

        return $utente;
    }

    // ---------------------------------------------------------------
    // Operazione 3: registra un artista (flusso alternativo)
    // ---------------------------------------------------------------
    public function registraArtista(
        string $nome,
        string $cognome,
        string $dataNascita,
        string $indirizzo,
        string $nickname,
        string $email,
        string $password,
        string $telefono,
        string $biografia,
        string $stileArtistico,
        string $portfolioOpere,
        string $fotoDocumento
    ): ?Artista {

        // Validazione base
        if ($this->pm->emailEsiste($email)) {
            echo "[CRegistrazione] ERRORE: email '$email' già registrata.\n";
            return null;
        }

        // Creazione oggetto di dominio (stato iniziale: 'in_attesa')
        $artista = new Artista(
            0, $nome, $cognome, $dataNascita, $indirizzo, $nickname, $email,
            password_hash($password, PASSWORD_DEFAULT),
            $telefono, $biografia, $stileArtistico, $portfolioOpere, $fotoDocumento,
            'in_attesa'
        );

        // Persistenza
        $this->pm->store($artista);

        // L'artista NON viene loggato automaticamente: deve aspettare validazione admin
        echo "[CRegistrazione] Artista '{$artista->getNickname()}' in attesa di validazione.\n";
        echo "[CRegistrazione] → notifica inviata all'amministratore\n";
        echo "[CRegistrazione] → messaggio a schermo: 'Account in attesa di verifica'\n";
        // In produzione: carica la View con il messaggio di attesa

        return $artista;
    }
}
