<?php

/**
 * TEST UC1 — Registrazione Account
 *
 * Esegui da terminale nella root del progetto:
 *   php Control/test_UC1.php
 *
 * Non richiede DB né web server: tutti i dati sono hardcoded.
 */

require_once __DIR__ . '/CRegistrazione.php';

$controller = new CRegistrazione();

echo "=== TEST 1: avviaRegistrazione() ===\n";
$controller->avviaRegistrazione();
echo "\n";

echo "=== TEST 2: registraUtente() — caso di successo ===\n";
$utente = $controller->registraUtente(
    nome:        'Mario',
    cognome:     'Rossi',
    dataNascita: '1995-06-15',
    indirizzo:   'Via Roma 1, Milano',
    nickname:    'mario95',
    email:       'mario@email.com',
    password:    'Password123!'
);
echo "Utente creato: " . ($utente ? $utente->getNickname() : 'ERRORE') . "\n";
echo "\n";

echo "=== TEST 3: registraUtente() — email già esistente ===\n";
$controller->registraUtente(
    nome:        'Luigi',
    cognome:     'Verdi',
    dataNascita: '1990-01-01',
    indirizzo:   'Via Po 5, Roma',
    nickname:    'luigi90',
    email:       'mario@email.com',   // stessa email → errore atteso
    password:    'AltroPassword1!'
);
echo "\n";

echo "=== TEST 4: registraArtista() — caso di successo ===\n";
$artista = $controller->registraArtista(
    nome:          'Anna',
    cognome:       'Bianchi',
    dataNascita:   '1988-03-22',
    indirizzo:     'Via Verdi 10, Firenze',
    nickname:      'annaart',
    email:         'anna@artista.com',
    password:      'SecurePass99!',
    telefono:      '+39 333 1234567',
    biografia:     'Pittrice fiorentina specializzata in acquerello.',
    stileArtistico:'Acquerello contemporaneo',
    portfolioOpere:'uploads/portfolio/anna/',
    fotoDocumento: 'uploads/docs/anna_ci.jpg'
);
echo "Artista creato: " . ($artista ? $artista->getNickname() . " — stato: " . $artista->getStato() : 'ERRORE') . "\n";
echo "\n";

echo "=== FINE TEST UC1 ===\n";
