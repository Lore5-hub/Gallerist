<?php

/**
 * Session — versione di TEST.
 * Usa un array statico invece dei veri cookie/session PHP,
 * così è testabile da CLI senza un web server.
 */
class Session {

    private static array $data = [];

    public static function set(string $key, mixed $value): void {
        self::$data[$key] = $value;
        echo "[Session] set('$key') — OK\n";
    }

    public static function get(string $key): mixed {
        return self::$data[$key] ?? null;
    }

    public static function destroy(): void {
        self::$data = [];
        echo "[Session] destroy() — sessione svuotata\n";
    }

    public static function isLoggedIn(): bool {
        return isset(self::$data['utente_id']);
    }
}
