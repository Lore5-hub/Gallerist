<?php

require_once __DIR__ . '/../Entity/Utente.php';
require_once __DIR__ . '/../Entity/Artista.php';
require_once __DIR__ . '/../Entity/Opera.php';
require_once __DIR__ . '/../Entity/Commento.php';

/**
 * PersistentManager — versione di TEST con dati hardcoded.
 * In questa fase NON si connette al DB: i metodi restituiscono
 * dati fittizi oppure simulano il salvataggio stampando a console.
 *
 * Cartella: Foundation/
 */
class PersistentManager {

    // ---------------------------------------------------------------
    // "DB" in memoria
    // ---------------------------------------------------------------
    private static array $utenti       = [];
    private static array $opere        = [];
    private static array $commenti     = [];
    private static array $transazioni  = [];
    private static array $offerte      = [];
    private static int   $nextId       = 1;


    // ===============================================================
    // UC1 — Registrazione
    // ===============================================================

    public function emailEsiste(string $email): bool {
        foreach (self::$utenti as $u) {
            if ($u->getEmail() === $email) return true;
        }
        return false;
    }

    public function store(Utente $utente): Utente {
        self::$utenti[self::$nextId] = $utente;
        echo "[PersistentManager] store() — Salvato utente id=" . self::$nextId
             . ", ruolo=" . $utente->getRuolo() . "\n";
        self::$nextId++;
        return $utente;
    }

    public function loadByEmail(string $email): ?Utente {
        foreach (self::$utenti as $u) {
            if ($u->getEmail() === $email) return $u;
        }
        return null;
    }


    // ===============================================================
    // UC2 — Catalogo (dati hardcoded per il testing)
    // ===============================================================

    /**
     * Restituisce un array di Opera filtrate e ordinate.
     * In questa versione di test i dati sono hardcoded.
     *
     * @param string $keyword        parola chiave sul titolo ('' = nessun filtro)
     * @param string $categoria      filtra per categoria    ('' = tutte)
     * @param string $ordinamento    'data' | 'prezzo_asc' | 'prezzo_desc'
     * @return Opera[]
     */
    public function getOpere(string $keyword = '', string $categoria = '', string $ordinamento = 'data'): array {
        // Dati hardcoded che simulano il DB
        $tutte = [
            new Opera(1, 'Alba sul mare',    2021, 'Olio su tela',  80, 60, 2, 'cm', 'Paesaggio marino al tramonto',  'Pittura', 'mare,luce',      ['img/alba.jpg'],      true,  1200.0, 10, 4.5),
            new Opera(2, 'Geometrie urbane', 2022, 'Acrilico',      50, 70, 0, 'cm', 'Composizione astratta urbana',  'Astratto','città,forma',    ['img/geo.jpg'],       false,    0.0, 11, 3.8),
            new Opera(3, 'Ritratto #3',      2020, 'Carboncino',    30, 40, 0, 'cm', 'Studio del volto umano',        'Disegno', 'ritratto,volto', ['img/ritratto.jpg'],  true,   450.0, 10, 4.9),
            new Opera(4, 'Scultura blu',     2019, 'Bronzo',        20, 35, 15,'cm', 'Forma organica in bronzo',      'Scultura','blu,bronzo',     ['img/scultura.jpg'],  true,  3500.0, 12, 4.2),
        ];

        // Filtro keyword
        if ($keyword !== '') {
            $tutte = array_filter($tutte, fn($o) => stripos($o->getTitolo(), $keyword) !== false
                                                  || stripos($o->getDescrizione(), $keyword) !== false);
        }

        // Filtro categoria
        if ($categoria !== '') {
            $tutte = array_filter($tutte, fn($o) => strcasecmp($o->getCategoria(), $categoria) === 0);
        }

        // Ordinamento
        $tutte = array_values($tutte);
        usort($tutte, function(Opera $a, Opera $b) use ($ordinamento) {
            return match($ordinamento) {
                'prezzo_asc'  => $a->getPrezzo() <=> $b->getPrezzo(),
                'prezzo_desc' => $b->getPrezzo() <=> $a->getPrezzo(),
                default       => $b->getId() <=> $a->getId(), // 'data': più recenti prima
            };
        });

        echo "[PersistentManager] getOpere(keyword='$keyword', categoria='$categoria', ord='$ordinamento') → " . count($tutte) . " risultati\n";
        return $tutte;
    }

    /**
     * Restituisce un'Opera dato il suo id, oppure null se non esiste.
     */
    public function getOpera(int $id): ?Opera {
        // Hardcoded per il testing
        $tutte = $this->getOpere();
        foreach ($tutte as $o) {
            if ($o->getId() === $id) {
                echo "[PersistentManager] getOpera(id=$id) → trovata '{$o->getTitolo()}'\n";
                return $o;
            }
        }
        echo "[PersistentManager] getOpera(id=$id) → non trovata\n";
        return null;
    }

    /**
     * Restituisce i commenti associati a un'opera.
     */
    public function getCommentiOpera(int $idOpera): array {
        // Hardcoded per il testing
        $tutti = [
            new Commento(1, 1, 20, 'luca_art',  'img/luca.jpg',  'Opera bellissima!',         5, '2024-03-01'),
            new Commento(2, 1, 21, 'sara99',    'img/sara.jpg',  'Colori molto vividi.',       4, '2024-03-05'),
            new Commento(3, 3, 20, 'luca_art',  'img/luca.jpg',  'Tecnica impeccabile.',       5, '2024-04-10'),
        ];
        $filtrati = array_values(array_filter($tutti, fn($c) => $c->getIdOpera() === $idOpera));
        echo "[PersistentManager] getCommentiOpera(idOpera=$idOpera) → " . count($filtrati) . " commenti\n";
        return $filtrati;
    }

    /**
     * Restituisce le altre opere dello stesso artista (esclusa quella corrente).
     */
    public function getAltreOpereArtista(int $idArtista, int $idOperaEsclusa): array {
        $tutte = $this->getOpere();
        $altre = array_values(array_filter($tutte, fn($o) => $o->getIdArtista() === $idArtista && $o->getId() !== $idOperaEsclusa));
        echo "[PersistentManager] getAltreOpereArtista(idArtista=$idArtista) → " . count($altre) . " opere\n";
        return $altre;
    }

    /**
     * Restituisce l'Artista dato il suo id (hardcoded per il testing).
     */
    public function getArtista(int $idArtista): ?Artista {
        $artisti = [
            new Artista(10, 'Anna',  'Bianchi', '1988-03-22', 'Firenze', 'annaart',   'anna@art.com',  '', '+39 333 111', 'Pittrice acquerellista', 'Acquerello', 'portfolio/anna/', 'docs/anna.jpg', 'attivo'),
            new Artista(11, 'Marco', 'Neri',    '1990-07-14', 'Milano',  'marconeri', 'marco@art.com', '', '+39 333 222', 'Artista astratto',       'Astratto',   'portfolio/marco/','docs/marco.jpg','attivo'),
            new Artista(12, 'Giulia','Ferri',   '1985-11-02', 'Roma',    'giuliaf',   'giulia@art.com','', '+39 333 333', 'Scultrice',              'Scultura',   'portfolio/giulia/','docs/giulia.jpg','attivo'),
        ];
        foreach ($artisti as $a) {
            if ($a->getId() === $idArtista) {
                echo "[PersistentManager] getArtista(id=$idArtista) → trovato '{$a->getNickname()}'\n";
                return $a;
            }
        }
        return null;
    }


    // ===============================================================
    // UC3 — Compravendita
    // ===============================================================

    /**
     * Registra una transazione di acquisto.
     * Restituisce l'id della transazione (hardcoded = 1 in test).
     */
    public function storeTransazione(array $dati): int {
        $idTransazione = self::$nextId++;
        self::$transazioni[$idTransazione] = $dati;
        echo "[PersistentManager] storeTransazione() — Transazione id=$idTransazione registrata\n";
        return $idTransazione;
    }

    /**
     * Aggiorna lo stato di vendita di un'opera (es. dopo acquisto: non più in vendita).
     */
    public function updateStatoOpera(int $idOpera, bool $inVendita): void {
        echo "[PersistentManager] updateStatoOpera(id=$idOpera, inVendita=" . ($inVendita ? 'true' : 'false') . ")\n";
    }

    /**
     * Registra un'offerta alternativa inviata da un utente a un artista.
     */
    public function storeOfferta(array $dati): int {
        $idOfferta = self::$nextId++;
        self::$offerte[$idOfferta] = $dati;
        echo "[PersistentManager] storeOfferta() — Offerta id=$idOfferta registrata\n";
        return $idOfferta;
    }
}
