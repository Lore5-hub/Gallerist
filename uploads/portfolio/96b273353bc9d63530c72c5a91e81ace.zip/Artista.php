<?php

require_once __DIR__ . '/Utente.php';

class Artista extends Utente {
    private string $telefono;
    private string $biografia;
    private string $stileArtistico;
    private string $portfolioOpere;   // path o URL della cartella/file portfolio
    private string $fotoDocumento;    // path o URL della foto del documento
    private string $stato;            // 'in_attesa' | 'attivo' | 'bannato'

    public function __construct(
        int    $id,
        string $nome,
        string $cognome,
        string $dataNascita,
        string $indirizzo,
        string $nickname,
        string $email,
        string $password,
        string $telefono,
        string $biografia,
        string $stileArtistico,
        string $portfolioOpere,
        string $fotoDocumento,
        string $stato = 'in_attesa'
    ) {
        parent::__construct($id, $nome, $cognome, $dataNascita, $indirizzo, $nickname, $email, $password, 'artista');
        $this->telefono       = $telefono;
        $this->biografia      = $biografia;
        $this->stileArtistico = $stileArtistico;
        $this->portfolioOpere = $portfolioOpere;
        $this->fotoDocumento  = $fotoDocumento;
        $this->stato          = $stato;
    }

    // --- Getter ---
    public function getTelefono(): string       { return $this->telefono; }
    public function getBiografia(): string      { return $this->biografia; }
    public function getStileArtistico(): string { return $this->stileArtistico; }
    public function getPortfolioOpere(): string { return $this->portfolioOpere; }
    public function getFotoDocumento(): string  { return $this->fotoDocumento; }
    public function getStato(): string          { return $this->stato; }

    // --- Setter (lo stato viene modificato dall'admin) ---
    public function setStato(string $stato): void { $this->stato = $stato; }
}
